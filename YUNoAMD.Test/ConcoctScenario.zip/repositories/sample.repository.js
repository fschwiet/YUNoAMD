define([ 'lib/repository' ], function(Repository) {
	return Repository.extend("SampleRepository", {
		root : 'api/sample/'
	}, {});
});